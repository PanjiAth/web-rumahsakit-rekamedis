<?php include_once('../_header.php');?>

                <div class="row">
                    <div class="col-lg-12">
                        <h1>Home</h1>
                        <p>Selamat datang <mark class="text-primary"><?=$_SESSION['user'];?></mark> Di Webside Rumah Sakit</p>
                        <a href="#menu-toggle" class="btn btn-warning" id="menu-toggle">Toggle Menu</a>
                    </div>
                </div>

<?php include_once('../_footer.php');?>
